import {AppBar, Grid, Toolbar, Typography} from "@mui/material";
import {Link, Route, Routes} from "react-router-dom";
import MainPage from "./MainPage";
import BasicTable from "./BasicTable";
import { ReactComponent as Logo } from './assets/wimble.svg';

const Navbar = () => {

    return (

        <div class="gradient">
            <AppBar position="static" style={{ background: '#13733d' }}>
                <Toolbar variant="dense"  >
                    <Logo />
                    {/*https://cdn.worldvectorlogo.com/logos/wimbledon-1.svg*/}
                    <Link to="/">
                        <Typography variant="h6" left>
                           Home
                        </Typography>
                    </Link>
                </Toolbar>
            </AppBar>
            <Routes>
                <Route path="/gentlemans" element={<BasicTable></BasicTable>}>
                </Route>

                <Route path="/ladies" element={<BasicTable></BasicTable>}>
                </Route>

                <Route path="/" element={<MainPage></MainPage>} >
                </Route>
            </Routes>


        </div>


    );
}

export default Navbar;