import React, {useState, useEffect} from 'react';
import {Button, Grid, Typography} from "@mui/material";
import {Link, NavLink,Route, Routes, useNavigate} from "react-router-dom";

import "./styles/style.css";
import wimbledonChampions from "wimbledon-champions";
import logo from "./assets/HD.jpg";
//https://w0.peakpx.com/wallpaper/538/618/HD-wallpaper-tennis-blue-tennis-court-tennis-ball.jpg

const MainPage = () => {
    const[Gname, gsetName] = useState([]);
    const[Lname, lsetName] = useState([]);

    const data = wimbledonChampions();
    let years = [];
    const nameG = [];
    const nameL = [];
    useEffect(()=>{
        data.map((row)=>{
            for(let i =0; i< row.titles.length;i++){
                years.push(row.titles[i].year +"  ")
            }
            if (row.titles[0].title === 'Gentlemen\'s Singles'){

                nameG.push({name:row.name, y: years,titles:row.titles.length})
            }
            else{
                nameL.push({name:row.name, y: years,titles:row.titles.length})
            }
            years = []
        });
        gsetName(nameG)
        console.log(Gname)
        lsetName(nameL)
        console.log(Lname)

    });
    return (
        <div>
            <Link to="/gentlemans" state={{data:Gname}}>
                <Button className="przycisk"  variant="contained">
                    Gentlemans
                </Button>
            </Link>

            <Link to="/ladies" state={{data:Lname}}>
                <Button className="przycisk2" variant="contained">
                    Ladies
                </Button>
            </Link>
            <Grid>
                <img src={logo} className="img-fluid"/>

            </Grid>

        </div>

    );
}
export default MainPage;