import {useLocation} from "react-router-dom";
import React, {useState} from "react";
import {styled} from "@mui/material/styles";
import TableCell, {tableCellClasses} from "@mui/material/TableCell";
import TableRow from "@mui/material/TableRow";
import Table from "@mui/material/Table";
import TableHead from "@mui/material/TableHead";
import TableBody from "@mui/material/TableBody";
import {Button} from "@mui/material";
import {sort} from "ramda";

export default function BasicTable() {
    const loca = useLocation();
    const [data] = useState(loca.state.data);
    const StyledTableCell = styled(TableCell)(({ theme }) => ({
        [`&.${tableCellClasses.head}`]: {
            backgroundColor: theme.palette.common.black,
            color: theme.palette.common.white
        },
        [`&.${tableCellClasses.body}`]: {
            fontSize: 14
        }
    }));

    const StyledTableRow = styled(TableRow)(({ theme }) => ({
        "&:nth-of-type(odd)": {
            backgroundColor: theme.palette.action.hover
        },
        // hide last border
        "&:last-child td, &:last-child th": {
            border: 0
        }
    }));
    function Sortuj(){
        const dane = data.map((rowws) => (rowws.titles));
        console.log(sort((a, b)=>a - b, dane));

    }
    function Przycisk(){

        return(
            <Button onClick={Sortuj}>
                sortuj
            </Button>
        )
    }


    return (
        <div style={{backgroundColor: '#ffffff' }}>
        <Table sx={{ minWidth: 450 }} aria-label="simple table">

            <TableHead>
                <StyledTableRow>
                    <StyledTableCell style={{ position: "sticky", left: 0 }}>
                        Champion
                    </StyledTableCell>
                    <StyledTableCell
                        style={{ position: "sticky", left: 0 }}
                        align="right"
                    >
                        Year
                    </StyledTableCell>
                    <StyledTableCell align="right">
                        Total
                    </StyledTableCell>
                </StyledTableRow>
            </TableHead>
            <TableBody>
                {data.map((rowws) => (
                    <StyledTableRow
                        key={rowws.name}

                        sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                    >
                        <StyledTableCell component="th" scope="row">
                            {rowws.name}
                        </StyledTableCell>
                        <StyledTableCell align="right">
                            {rowws.y}
                        </StyledTableCell>
                        <StyledTableCell align="right" >
                            {rowws.titles}
                        </StyledTableCell>
                    </StyledTableRow>
                ))}
            </TableBody>
        </Table>
    </div>
    );
}
